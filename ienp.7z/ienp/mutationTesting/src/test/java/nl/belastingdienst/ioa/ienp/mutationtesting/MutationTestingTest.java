package nl.belastingdienst.ioa.ienp.mutationtesting;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import nl.belastingdienst.ioa.ienp.mutationtesting.MutationTesting;

/**
 * Met dank aan Roy van Rijn - https://www.youtube.com/watch?v=aLAcvMI2VBI 
 */
public class MutationTestingTest {

	@Test
	public void berekenMetZonderKorting() {
		Assert.assertThat(new MutationTesting().getAankoopbedrag(1, false), CoreMatchers.is(17));
	}

	@Test
	public void berekenMetKortingDoorAantal() {
		Assert.assertThat(new MutationTesting().getAankoopbedrag(100, false), CoreMatchers.is(1500));
	}

	@Test
	public void berekenMetKortingDoorKortingsbon() {
		Assert.assertThat(new MutationTesting().getAankoopbedrag(1, true), CoreMatchers.is(15));
	}

	@Test
	@Ignore
	public void berekenMetKortingRandgeval() {
		Assert.assertThat(new MutationTesting().getAankoopbedrag(20, false), CoreMatchers.is(300));
	}

}
