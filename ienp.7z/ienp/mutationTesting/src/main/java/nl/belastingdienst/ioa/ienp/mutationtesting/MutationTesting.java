package nl.belastingdienst.ioa.ienp.mutationtesting;

public class MutationTesting {

	public int getAankoopbedrag(int aantal, boolean heeftKortingsbon) {
		if(aantal >= 20 || heeftKortingsbon) {
			return aantal * 15;
		}
		return aantal * 17;
	}
	
}
