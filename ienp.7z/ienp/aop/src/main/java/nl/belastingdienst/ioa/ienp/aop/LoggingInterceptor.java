package nl.belastingdienst.ioa.ienp.aop;

import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

import org.aspectj.lang.annotation.Around;

//@Logable
@Interceptor
public class LoggingInterceptor {

	// @AroundInvoke
	@Around("execution(void aspects.TestAspect.hello())")
	public void log(InvocationContext ctx) throws Exception {
		System.out.println("In LoggingInterceptor");
	}
}
