package nl.belastingdienst.ioa.ienp.lombok;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Test;

public class LombokAnnotatedObjectTest {

	@Test
	public void areMethodsGenerated() {
		Assert.assertThat(LombokAnnotatedObject.builder().id(1).build().getId(), CoreMatchers.is(1));
		Assert.assertThat(new LombokAnnotatedObject(1).getId(), CoreMatchers.is(1));		
	}
}