package nl.belastingdienst.ioa.ienp.lombok;

import lombok.Builder;
import lombok.Data;

@Builder @Data
public class LombokAnnotatedObject {
	
	private int id;

}