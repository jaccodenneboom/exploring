package nl.belastingdienst.ioa.ienp.logging;

import java.util.Date;

import org.apache.log4j.Logger;
import org.slf4j.LoggerFactory;

public class LogObject {

	private static final Logger LOG4JLOGGER = Logger.getLogger(LogObject.class);
	private static final org.apache.logging.log4j.Logger LOG4J2LOGGER = org.apache.logging.log4j.LogManager
			.getLogger(LogObject.class);
	private static final org.slf4j.Logger SLF4JLOGGER = LoggerFactory.getLogger(LogObject.class);

	public LogObject(int id) {
		super();
		this.id = id;
	}

	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public static void main(String[] args) {
		LOG4JLOGGER.debug("Bericht met id " + new LogObject(1).getId() + " is geregistreerd op " + new Date() + ".");
		LOG4J2LOGGER.debug("Bericht met id {} is geregistreerd op {}.", new LogObject(2).getId(), new Date());
		SLF4JLOGGER.debug("Bericht met id {} is geregistreerd op {}.", new LogObject(3).getId(), new Date());
	}

}
